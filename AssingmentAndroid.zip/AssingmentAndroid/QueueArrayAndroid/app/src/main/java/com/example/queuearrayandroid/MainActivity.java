package com.example.queuearrayandroid;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    /**
     * Called when the user taps the Enqueue button
     * Adds an item to the queue
     */
    public void enqueue(View view) {
        final EditText editTextElement = (EditText) findViewById(R.id.editText2);
        final TextView firstElement = (TextView) findViewById(R.id.editText3);
        final TextView secondElement = (TextView) findViewById(R.id.editText4);
        final TextView thirdElement = (TextView) findViewById(R.id.editText5);

        final String inputText = editTextElement.getText().toString();
        final String firstText = firstElement.getText().toString();
        final String secondText = secondElement.getText().toString();
        final String thirdText = thirdElement.getText().toString();
        //  firstElement.setText(inputText);

        if(thirdElement != null && !"".equals(thirdText.trim())) {
            showMessage();
        }

        else if (thirdElement == null || "".equals(thirdText.trim())
                && (secondElement != null && !"".equals(secondText.trim()))
                && (firstText != null && !"".equals(firstText.trim()))) {

            thirdElement.setText(editTextElement.getText());

        } else if (secondElement == null || "".equals(secondText.trim())
                && (firstText != null && !"".equals(firstText.trim()))) {

            secondElement.setText(editTextElement.getText());
        } else {
            firstElement.setText(editTextElement.getText());
        }

        editTextElement.setText("");
    }

    /**
     * Called when the Array is full. Displays a message on the UI
     * that the queue is full if the user tries to add more items
     */
    private void showMessage() {
        Context context = getApplicationContext();
        CharSequence text = "Array Full! Dequeue Few Numbers";
        int duration = Toast.LENGTH_LONG;

        Toast toast = Toast.makeText(context, text, duration);
        toast.setGravity(Gravity.CENTER | Gravity.CENTER, 0, 0);
        toast.show();
    }

    /**
     * Called when the Queue is empty. Displays a message on the UI
     * that the queue is empty if the user tries to removes items from empty array
     */
    private void showDequeueMessage() {
        Context context = getApplicationContext();
        CharSequence text = "Array Empty! Enqueue few numbers";
        int duration = Toast.LENGTH_LONG;

        Toast toast = Toast.makeText(context, text, duration);
        toast.setGravity(Gravity.CENTER | Gravity.CENTER, 0, 0);
        toast.show();
    }

    /**
     * Called when the user taps the Clear button
     * Cleans the queue
     */

    public void clear(View view) {
        final EditText editTextElement = (EditText) findViewById(R.id.editText2);
        final TextView firstElement = (TextView) findViewById(R.id.editText3);
        final TextView secondElement = (TextView) findViewById(R.id.editText4);
        final TextView thirdElement = (TextView) findViewById(R.id.editText5);

        firstElement.setText("");
        secondElement.setText("");
        thirdElement.setText("");
        editTextElement.setText("");
    }

    /**
     * Called when the user taps the Dequeue button
     * Removes the first item added from the array
     */
    public void dequeue(View view) {
        final TextView firstElement = (TextView) findViewById(R.id.editText3);
        final TextView secondElement = (TextView) findViewById(R.id.editText4);
        final TextView thirdElement = (TextView) findViewById(R.id.editText5);

        final String firstText = firstElement.getText().toString();
        final String secondText = secondElement.getText().toString();
        final String thirdText = thirdElement.getText().toString();

        if(firstElement == null || "".equals(firstText.trim())
        && secondElement == null || "".equals(secondText.trim())
        && thirdElement == null || "".equals(thirdText.trim()))
        {
            showDequeueMessage();
        }

        else if (firstElement != null && !"".equals(firstText.trim())

        ) {

            firstElement.setText("");

        } else if ( secondElement != null && !"".equals(secondText.trim()))
        {
            secondElement.setText("");
        } else if ( thirdElement != null && !"".equals(thirdText.trim()))
        {
            thirdElement.setText("");
        }

    }
}
