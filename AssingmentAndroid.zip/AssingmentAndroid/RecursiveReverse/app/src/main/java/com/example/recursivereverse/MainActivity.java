package com.example.recursivereverse;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    /**
     * Called when the Text is empty. Displays a message on the UI
     * that the text is empty and ask the user to enter a string
     */
    private void showMessage() {
        Context context = getApplicationContext();
        CharSequence text = "Enter the string to reverse";
        int duration = Toast.LENGTH_LONG;

        Toast toast = Toast.makeText(context, text, duration);
        toast.setGravity(Gravity.CENTER | Gravity.CENTER, 0, 0);
        toast.show();
    }

    /**
     * Called when the user taps the Reverse button
     * Recursive function is invoked when reverse button is clicked
     */

    public void reverse(View view) {
        final TextView editTextView = (TextView) findViewById(R.id.editText);
        final TextView outputTextView = (TextView) findViewById(R.id.editText3);

        final String editText = editTextView.getText().toString();

        if(editTextView == null || "".equals(editText.trim())) {
            showMessage();
        }

        outputTextView.setText(reverseString(editText));

    }

    public String reverseString(String myStr)
    {
        if (myStr.isEmpty()){
            return myStr;
        }
        //Calling Function Recursively
        return reverseString(myStr.substring(1)) + myStr.charAt(0);
    }

}
